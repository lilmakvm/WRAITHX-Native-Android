plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.lilma.wraithx"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.lilma.wraithx"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
