package com.lilma.wraithx

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private var lightMode = false
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private val cyan = Color.rgb(103, 232, 249)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        lightMode = getPreferences(MODE_PRIVATE).getBoolean("light_mode", false)
        render()
    }

    private fun bg(color: Int, radius: Float = 24f, stroke: Int = Color.TRANSPARENT): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius
            if (stroke != Color.TRANSPARENT) setStroke(1, stroke)
        }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(0, 6, 0, 6)
        }

    private fun button(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 15f
            setTextColor(if (lightMode) Color.rgb(20, 32, 48) else Color.WHITE)
            background = bg(if (lightMode) Color.rgb(235, 241, 248) else Color.rgb(25, 29, 40), 18f,
                if (lightMode) Color.rgb(210, 219, 232) else Color.rgb(54, 62, 79))
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(10)
            }
        }

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()

    private fun render() {
        val page = if (lightMode) Color.rgb(247, 249, 252) else Color.rgb(5, 7, 12)
        val panel = if (lightMode) Color.WHITE else Color.rgb(14, 17, 25)
        val fg = if (lightMode) Color.rgb(22, 29, 44) else Color.rgb(239, 243, 250)
        val muted = if (lightMode) Color.rgb(95, 107, 128) else Color.rgb(145, 155, 174)

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(18))
            setBackgroundColor(page)
        }
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        content.addView(text("WRAITHX  /  SHADOW INTERFACE", 12f, cyan, true))
        content.addView(text("Your digital territory.", 28f, fg, true).apply {
            setPadding(0, dp(8), 0, dp(18))
        })

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(8))
            background = bg(panel, 24f, if (lightMode) Color.rgb(225, 231, 239) else Color.rgb(38, 43, 56))
        }
        content.addView(card)
        card.addView(text("SYSTEM CONTROLS", 12f, muted, true))
        card.addView(button("▦  Control Center  —  Open Android Quick Settings") {
            val service = QuickSettingsAccessibilityService.instance
            if (service != null) {
                service.openQuickSettings()
            } else {
                Toast.makeText(this, "Enable WRAITHX Quick Settings in Accessibility settings first.", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        })
        card.addView(button("☀  Appearance: ${if (lightMode) "Light mode" else "Dark mode"}") {
            lightMode = !lightMode
            getPreferences(MODE_PRIVATE).edit().putBoolean("light_mode", lightMode).apply()
            render()
        })
        card.addView(button("⚙  Android system settings") {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        })
        card.addView(button("⌂  Set WRAITHX as default Home app") {
            Toast.makeText(this, "Choose WRAITHX when Android asks for your Home app.", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
        })

        content.addView(text("APPLICATIONS", 12f, muted, true).apply { setPadding(0, dp(24), 0, dp(10)) })
        val apps = listOf(
            "Phone", "Messages", "Camera", "Chrome", "Settings", "Files",
            "YouTube", "Play Store", "eFootball", "Call of Duty"
        )
        apps.forEach { label ->
            content.addView(button("▣   $label") { launchApp(label) })
        }
        content.addView(text("WRAITHX is a native launcher starter. Some device controls require Android permission or may vary by manufacturer.", 12f, muted).apply {
            setPadding(0, dp(18), 0, dp(18))
        })

        setContentView(root)
    }

    private fun launchApp(label: String) {
        val packages = when (label) {
            "Phone" -> listOf("com.google.android.dialer", "com.android.dialer")
            "Messages" -> listOf("com.google.android.apps.messaging", "com.android.mms")
            "Camera" -> listOf("com.oplus.camera", "com.android.camera2", "com.android.camera")
            "Chrome" -> listOf("com.android.chrome")
            "Settings" -> listOf("com.android.settings")
            "Files" -> listOf("com.google.android.documentsui", "com.android.documentsui", "com.oplus.filemanager")
            "YouTube" -> listOf("com.google.android.youtube")
            "Play Store" -> listOf("com.android.vending")
            "eFootball" -> listOf("jp.konami.pesam")
            "Call of Duty" -> listOf("com.activision.callofduty.shooter")
            else -> emptyList()
        }
        for (pkg in packages) {
            val intent = packageManager.getLaunchIntentForPackage(pkg)
            if (intent != null) {
                startActivity(intent)
                return
            }
        }
        Toast.makeText(this, "$label wasn't found. The app may not be installed or may use a different package name.", Toast.LENGTH_LONG).show()
    }
}
